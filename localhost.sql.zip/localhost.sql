-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 09, 2016 at 10:39 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `forum`
--
CREATE DATABASE IF NOT EXISTS `forum` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `forum`;

-- --------------------------------------------------------

--
-- Table structure for table `msg`
--

CREATE TABLE `msg` (
  `msg_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `body` char(250) NOT NULL,
  `datemsg` datetime NOT NULL,
  `username` varchar(50) NOT NULL,
  `groups` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `msg`
--

INSERT INTO `msg` (`msg_id`, `title`, `body`, `datemsg`, `username`, `groups`) VALUES
(20, 'ergerhrjyuk tyr', 'jytjwjw thrthrthhhr htrh', '2016-12-01 15:25:28', 'denninnka1', '0'),
(21, 'hmthmukuiky', 'lululul', '2016-12-01 15:26:05', 'emiliq', '0'),
(22, 'rrgnrgnr', 'cbbcbcb', '2016-12-01 15:26:15', 'emiliq', '0'),
(23, 'dfbhdhd', 'fghrthejh', '2016-12-01 15:26:29', 'denninnka', '0'),
(24, 'nhnhnh', 'nhhnh', '2016-12-01 15:26:37', 'denninnka', '0'),
(25, 'kikikiki', 'kikiki', '2016-12-01 15:26:58', 'denninnka1', '0'),
(28, 'dfdfdfdd', 'fdfdfdfd', '2016-12-01 15:27:46', 'denninnka', '0'),
(29, 'bgbgbg', 'bgbgbgbg', '2016-12-01 15:28:03', 'denninnka1', '0'),
(31, 'fgwegwrgwr', 'egwgw', '2016-12-05 18:09:25', 'denninnka1', '1'),
(32, 'dfsaascfac', 'cacavav', '2016-12-05 18:11:59', 'denninnka1', '3'),
(33, 'sfafaffa', 'fafafaf', '2016-12-08 10:01:58', 'emiliq', '1'),
(34, 'aaa', 'asdasd', '2016-12-08 10:18:40', 'emiliq', '0'),
(35, 'sdgsg', 'sbgsdbsb', '2016-12-08 10:26:13', 'emiliq', '2'),
(36, 'rtert', 'twetyt', '2016-12-08 10:34:48', 'emiliq', '1'),
(37, 'dfhre', 'yey', '2016-12-08 10:36:39', 'emiliq', '3'),
(38, 'сфсадгаг', 'дгсгсга', '2016-12-08 10:48:38', 'emiliq', '1'),
(39, 'сдрфгсг', 'гсгсг', '2016-12-08 10:48:56', 'emiliq', '1'),
(40, 'sfwg', 'wegwgww', '2016-12-08 10:52:41', 'emiliq', '2');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `admin`) VALUES
(1, 'denninnka', 'qwerty', 1),
(2, 'denninnka1', '1q2w3e4r', 0),
(3, 'emiliq', 'qawsedrf', 0),
(4, 'denisatsoneva', '123456', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `msg`
--
ALTER TABLE `msg`
  ADD PRIMARY KEY (`msg_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `msg`
--
ALTER TABLE `msg`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
